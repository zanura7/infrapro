'use client';

import { useState, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Upload, Image as ImageIcon, Video, Copy, Loader2, Sparkles, AlertCircle, Download, FileText, Check } from 'lucide-react';
import { motion } from 'motion/react';
import ReactMarkdown from 'react-markdown';

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: process.env.NEXT_PUBLIC_GEMINI_API_KEY });

const ENVIRONMENTS = [
  { id: '1', name: 'Gudang Overload', desc: 'warehouse penuh stok' },
  { id: '2', name: 'Sistem Distribusi Massal', desc: 'logistik & kurir' },
  { id: '3', name: 'Pasar Viral', desc: 'pasar ramai + motor' },
  { id: '4', name: 'Produksi Pabrik', desc: 'produksi & mesin' },
  { id: '5', name: 'Social Proof Crowd', desc: 'kerumunan sosial proof' },
  { id: '6', name: 'Display Retail Mall', desc: 'retail modern' },
  { id: '7', name: 'Lini Produksi Conveyor', desc: 'lini produksi' },
  { id: '8', name: 'Konveyor Produk Cair', desc: 'botol/isi cair' },
  { id: '9', name: 'Promosi Musiman', desc: 'dekor diskon' },
  { id: '10', name: 'Etalase Mall Premium', desc: 'etalase mewah' },
  { id: '11', name: 'Musim Panen', desc: 'nuansa rural' },
  { id: '12', name: 'Panic Buying Store', desc: 'rebutan barang' },
  { id: '13', name: 'TV Shopping Studio', desc: 'studio terang' },
  { id: '14', name: 'Lapak Viral Jalanan', desc: 'lapak pinggir jalan' },
  { id: '15', name: 'Wawancara Jalanan', desc: 'wawancara' },
  { id: '16', name: 'Area Bandara', desc: 'travel' },
  { id: '17', name: 'Pasar Malam', desc: 'night market' },
  { id: '18', name: 'Supermarket', desc: 'rak modern' },
  { id: '19', name: 'Hypermarket', desc: 'besar & bulk' },
  { id: '20', name: 'Demo Produk Jalanan', desc: 'live demo' },
  { id: '21', name: 'Demo Influencer', desc: 'konten creator' },
  { id: '22', name: 'Logistik Pelabuhan', desc: 'kontainer' },
  { id: '23', name: 'Booth Festival', desc: 'booth event' },
  { id: '24', name: 'Toko Gadget', desc: 'toko elektronik' },
  { id: '25', name: 'Toko Perlengkapan Rumah', desc: 'home goods' },
  { id: '26', name: 'Toko Kecantikan', desc: 'kosmetik' },
  { id: '27', name: 'Toko Fashion', desc: 'butik' },
  { id: '28', name: 'Lokasi Konstruksi', desc: 'proyek' },
  { id: '29', name: 'Toko Aksesoris Mobil', desc: 'aksesoris mobil' },
  { id: '30', name: 'Toko Olahraga', desc: 'sport store' },
  { id: '31', name: 'Pasar Elektronik', desc: 'pasar gadget' },
  { id: '32', name: 'Toko Perkakas', desc: 'tools' },
  { id: '33', name: 'Bazaar Akhir Pekan', desc: 'outdoor santai' },
  { id: '34', name: 'Kampus Universitas', desc: 'mahasiswa' },
  { id: '35', name: 'Demo Kantor', desc: 'office demo' }
];

export default function App() {
  const [image, setImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [environment, setEnvironment] = useState<string>('1');
  const [sceneCount, setSceneCount] = useState<string>('4');
  const [language, setLanguage] = useState<string>('indonesian');
  const [productContext, setProductContext] = useState<string>('');
  
  const [isGenerating, setIsGenerating] = useState(false);
  const [isGeneratingImageForScene, setIsGeneratingImageForScene] = useState<Record<number, boolean>>({});
  const [result, setResult] = useState<string | null>(null);
  const [generatedImages, setGeneratedImages] = useState<Record<number, string>>({});
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const parseScenes = (text: string) => {
    const scenes = [];
    for (let i = 1; i <= 10; i++) {
      const voMatch = text.match(new RegExp('### Voiceover Script Scene ' + i + '\\s*([\\s\\S]*?)(?=###|$)', 'i'));
      const t2iMatch = text.match(new RegExp('### Prompt Text to Image Scene ' + i + '\\s*```(?:text)?\\n([\\s\\S]*?)```', 'i')) || 
                       text.match(new RegExp('### Prompt Text to Image Scene ' + i + '\\s*([\\s\\S]*?)(?=###|$)', 'i'));
      const i2vMatch = text.match(new RegExp('### Prompt Image to Video Scene ' + i + '\\s*```(?:text)?\\n([\\s\\S]*?)```', 'i')) ||
                       text.match(new RegExp('### Prompt Image to Video Scene ' + i + '\\s*([\\s\\S]*?)(?=###|$)', 'i'));
                       
      if (voMatch || t2iMatch || i2vMatch) {
         scenes.push({
           num: i,
           voiceover: voMatch ? voMatch[1].trim() : '',
           textToImage: t2iMatch ? t2iMatch[1].replace(/```.*/g,'').trim() : '',
           imageToVideo: i2vMatch ? i2vMatch[1].replace(/```.*/g,'').trim() : ''
         });
      } else {
         if (i > 1) break;
      }
    }
    return scenes;
  };

  const markdownComponents = {
    code({ node, inline, className, children, ...props }: any) {
      const match = /language-(\w+)/.exec(className || '');
      const content = String(children).replace(/\n$/, '');
      
      if (!inline) {
        return (
          <div className="relative group mt-4 mb-6">
            <div className="absolute right-2 top-2 opacity-0 group-hover:opacity-100 transition-opacity">
              <button
                onClick={() => navigator.clipboard.writeText(content)}
                className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition-colors"
                title="Copy to clipboard"
              >
                <Copy className="w-4 h-4" />
              </button>
            </div>
            <pre className="bg-slate-900 text-slate-50 p-4 rounded-xl overflow-x-auto text-sm font-mono leading-relaxed">
              <code className={className} {...props}>
                {children}
              </code>
            </pre>
          </div>
        );
      }
      return (
        <code className="bg-slate-100 text-indigo-600 px-1.5 py-0.5 rounded-md font-mono text-sm" {...props}>
          {children}
        </code>
      );
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
      setResult(null);
      setGeneratedImages({});
      setError(null);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('image/')) {
      setImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
      setResult(null);
      setGeneratedImages({});
      setError(null);
    }
  };

  const generatePrompts = async () => {
    if (!image || !imagePreview) return;

    setIsGenerating(true);
    setError(null);
    setGeneratedImages({});

    try {
      const base64Data = imagePreview.split(',')[1];
      const selectedEnv = ENVIRONMENTS.find(e => e.id === environment) || ENVIRONMENTS[0];
      const envPrompt = `${selectedEnv.id} ${selectedEnv.name} (${selectedEnv.desc})`;
      const languageName = language === 'indonesian' ? 'Indonesian' : language === 'malay' ? 'Malay' : 'English';

      const prompt = `
SYSTEM_MODE = VISUAL_AFFILIATE_STORY_ENGINE_V1

ROLE
Generate ultra-realistic visual prompts and voiceover scripts for AI affiliate videos. The voiceover script MUST be generated exclusively in the ${languageName} language.

Scenes must feel like authentic documentary footage in real environments with natural, unscripted human behavior aligned with the selected language's typical local setting.

------------------------------------------------
CORE OUTPUT RULE
------------------------------------------------

Output MUST be:
- ${sceneCount} SCENES

Each scene:
- 1 VOICEOVER SCRIPT (Please format section heading exactly as: ### Voiceover Script Scene X)
- 1 PROMPT TEXT TO IMAGE (Please format section heading exactly as: ### Prompt Text to Image Scene X) and enclose the prompt text in a \`\`\`text block.
- 1 PROMPT IMAGE TO VIDEO (Please format section heading exactly as: ### Prompt Image to Video Scene X) and enclose the prompt text in a \`\`\`text block.

DO NOT combine blocks. Always keep them strictly separate.

------------------------------------------------
ENVIRONMENT SELECTED
------------------------------------------------
${envPrompt}

${productContext.trim() ? `------------------------------------------------\nPRODUCT CONTEXT\n------------------------------------------------\n${productContext.trim()}\n` : ''}

------------------------------------------------
SCENE STRUCTURE
------------------------------------------------

${sceneCount === '4' ? `4 SCENES:
1 WHY (kerumunan/permintaan tinggi)  
2 WHAT (fitur/demo produk)  
3 WHO (interaksi & reaksi)  
4 RESULT (transaksi)` : `5 SCENES:
1 WHY (rebutan/panic)  
2 WHAT (demo)  
3 WHO (reaksi)  
4 PROOF (dipakai nyata)  
5 RESULT (closing)`}

------------------------------------------------
VISUAL REALISM
------------------------------------------------
- Handheld documentary style  
- Natural lighting  
- Slight camera shake  
- Real crowd movement  
- No over-cinematic look  

------------------------------------------------
LOCALIZATION & LANGUAGE
------------------------------------------------
Language for Voiceover Script: ${languageName}

If Indonesian:
- Include Indonesian people, tropical lighting, motorbikes, Indonesian signage, real market vibes, casual clothing.

If Malay:
- Include Malaysian people, tropical lighting, Malay signage, local market vibes, casual clothing.

If English:
- Include people of diverse/global origins, global/modern settings, English signage.

------------------------------------------------
BEHAVIOR STYLE
------------------------------------------------
People:
- Touch product naturally  
- Talk casually  
- Show curiosity  
- React subtle (not acting)  

------------------------------------------------
PRODUCT LOCK
------------------------------------------------
Product MUST match image exactly:
- Shape  
- Color  
- Label  
- Material  
- Proportion  
NO changes allowed.

------------------------------------------------
CROWD PSYCHOLOGY
------------------------------------------------
Include:
- Urgency (rebutan)  
- Social proof  
- Interaction (cek barang)  
- Conversion (ambil/bayar)

------------------------------------------------
CAMERA STYLE
------------------------------------------------
- Handheld  
- Natural pan  
- Close-up for demo  
- Over-shoulder  
- Follow shot (closing)

Analyze the uploaded product image. Use the specified environment and scene structure to generate the prompts exactly matching the requested format.
`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: [
          { inlineData: { mimeType: image.type, data: base64Data } },
          { text: prompt }
        ]
      });

      setResult(response.text ?? null);
    } catch (err) {
      console.error("Error generating content:", err);
      setError(err instanceof Error ? err.message : "An error occurred while generating the prompts.");
    } finally {
      setIsGenerating(false);
    }
  };

  const generateImageForScene = async (sceneNum: number, promptText: string) => {
    if (!image || !imagePreview) return;

    setIsGeneratingImageForScene(prev => ({...prev, [sceneNum]: true}));
    setError(null);

    try {
      const base64Data = imagePreview.split(',')[1];
      
      let extractedPrompt = promptText.trim();

      if (!extractedPrompt) {
        extractedPrompt = "Generate a high-quality commercial product image matching the reference.";
      }

      const languageName = language === 'indonesian' ? 'Indonesian' : language === 'malay' ? 'Malaysian' : 'Western/Global';

      const imagePrompt = `
        Generate a photorealistic image based on the reference image provided and the following description:
        ${extractedPrompt}
        
        IMPORTANT: The product in the generated image MUST look exactly like the product in the reference image. 
        Maintain the product's shape, color, label, and packaging details. 
        STRICT RULES: same exact product, no variation, no redesign, consistent shape and color, no mutation, fixed identity, identical object.
        The environment and people should match ${languageName} settings.
        The aspect ratio must be 9:16.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: [
          { inlineData: { mimeType: image.type, data: base64Data } },
          { text: imagePrompt }
        ],
        config: {
          imageConfig: {
            aspectRatio: '9:16'
          }
        }
      });

      let foundImage = null;
      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData?.data) {
            foundImage = `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
            break;
          }
        }
      }

      if (!foundImage) {
        throw new Error("No image was generated.");
      }

      setGeneratedImages(prev => ({...prev, [sceneNum]: foundImage!}));
    } catch (err) {
      console.error(`Error generating image for scene ${sceneNum}:`, err);
      setError(err instanceof Error ? err.message : "An error occurred while generating the image.");
    } finally {
      setIsGeneratingImageForScene(prev => ({...prev, [sceneNum]: false}));
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-indigo-100 selection:text-indigo-900">
      <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        
        {/* Header */}
        <header className="mb-12 text-center relative">
          <div className="inline-flex items-center justify-center mb-6">
            <img 
              src="/logo.jpg" 
              alt="Story Engine Logo" 
              className="w-24 h-24 rounded-3xl shadow-xl object-cover"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
                e.currentTarget.nextElementSibling?.classList.remove('hidden');
              }}
            />
            <div className="hidden p-3 bg-indigo-600 rounded-2xl shadow-lg">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold tracking-tight text-slate-900 mb-4">
            Visual Affiliate Story Engine
          </h1>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto flex items-center justify-center gap-2">
            {language === 'indonesian' ? '🇮🇩 Indonesia Localized Prompts' : language === 'malay' ? '🇲🇾 Malaysia Localized Prompts' : '🇬🇧 Global Localized Prompts'}
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Column: Input */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Image Upload Card */}
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
              <div className="p-6 border-b border-slate-100">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <ImageIcon className="w-5 h-5 text-indigo-600" />
                  Product Image
                </h2>
              </div>
              
              <div className="p-6">
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={handleDrop}
                  className={`
                    relative group cursor-pointer border-2 border-dashed rounded-xl p-8 text-center transition-all duration-200
                    ${imagePreview ? 'border-indigo-200 bg-indigo-50/30' : 'border-slate-300 hover:border-indigo-400 hover:bg-slate-50'}
                  `}
                >
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    onChange={handleImageUpload} 
                    accept="image/*" 
                    className="hidden" 
                  />
                  
                  {imagePreview ? (
                    <div className="relative aspect-[3/4] max-h-[400px] mx-auto overflow-hidden rounded-lg shadow-md">
                      <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <p className="text-white font-medium flex items-center gap-2">
                          <Upload className="w-4 h-4" /> Change Image
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4 py-8">
                      <div className="w-16 h-16 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center mx-auto">
                        <Upload className="w-8 h-8" />
                      </div>
                      <div>
                        <p className="text-base font-medium text-slate-900">Upload product image</p>
                        <p className="text-sm text-slate-500 mt-1">Supports JPG, PNG, WEBP</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Product Details Card */}
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
              <div className="p-6 border-b border-slate-100">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <FileText className="w-5 h-5 text-indigo-600" />
                  Product Context (Optional)
                </h2>
              </div>
              <div className="p-6">
                <textarea
                  value={productContext}
                  onChange={(e) => setProductContext(e.target.value)}
                  placeholder="Enter product specifics or details you want highlighted..."
                  className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-600 focus:border-indigo-600 transition-all resize-none outline-none"
                  rows={3}
                />
              </div>
            </div>

            {/* Configuration Card */}
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
              <div className="p-6 border-b border-slate-100">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <Video className="w-5 h-5 text-indigo-600" />
                  Story Configuration
                </h2>
              </div>
              
              <div className="p-6 space-y-6">
                
                <div className="grid grid-cols-2 gap-4">
                  {/* Scene Count */}
                  <div className="space-y-3">
                    <label className="text-sm font-medium text-slate-700">Scene Count</label>
                    <div className="flex flex-col gap-2">
                      <button
                        onClick={() => setSceneCount('4')}
                        className={`
                          px-4 py-2.5 rounded-xl text-sm font-medium text-center transition-all
                          ${sceneCount === '4' 
                            ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200 ring-2 ring-indigo-600 ring-offset-2' 
                            : 'bg-slate-50 text-slate-600 hover:bg-slate-100'}
                        `}
                      >
                        4 (Standard)
                      </button>
                      <button
                        onClick={() => setSceneCount('5')}
                        className={`
                          px-4 py-2.5 rounded-xl text-sm font-medium text-center transition-all
                          ${sceneCount === '5' 
                            ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200 ring-2 ring-indigo-600 ring-offset-2' 
                            : 'bg-slate-50 text-slate-600 hover:bg-slate-100'}
                        `}
                      >
                        5 (Viral)
                      </button>
                    </div>
                  </div>

                  {/* Language */}
                  <div className="space-y-3">
                    <label className="text-sm font-medium text-slate-700">Language</label>
                    <div className="flex flex-col gap-2">
                      {[
                        { id: 'indonesian', label: '🇮🇩 Indonesia' },
                        { id: 'malay', label: '🇲🇾 Melayu' },
                        { id: 'english', label: '🇬🇧 English' }
                      ].map(lang => (
                        <button
                          key={lang.id}
                          onClick={() => setLanguage(lang.id)}
                          className={`
                            px-3 py-2 rounded-xl text-sm font-medium text-left transition-all
                            ${language === lang.id 
                              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200 ring-2 ring-indigo-600 ring-offset-2' 
                              : 'bg-slate-50 text-slate-600 hover:bg-slate-100'}
                          `}
                        >
                          {lang.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Environment Selection */}
                <div className="space-y-3">
                  <label className="text-sm font-medium text-slate-700 block">Environment</label>
                  <div className="grid grid-cols-1 overflow-y-auto max-h-[400px] border border-slate-200 rounded-xl divide-y divide-slate-100 bg-white">
                    {ENVIRONMENTS.map((env) => (
                      <button
                        key={env.id}
                        onClick={() => setEnvironment(env.id)}
                        className={`
                          p-3 text-left transition-all flex items-center justify-between
                          ${environment === env.id 
                            ? 'bg-indigo-50 text-indigo-900 border-l-4 border-l-indigo-600' 
                            : 'bg-white text-slate-600 hover:bg-slate-50 border-l-4 border-l-transparent'}
                        `}
                      >
                        <div className="pr-4">
                          <span className="font-medium mr-2 text-indigo-400">{env.id}</span>
                          <span className="font-semibold text-slate-800">{env.name}</span>
                          <p className="text-xs text-slate-500 mt-0.5 ml-6">{env.desc}</p>
                        </div>
                        {environment === env.id && <Check className="w-5 h-5 text-indigo-600 shrink-0" />}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={generatePrompts}
                  disabled={!image || isGenerating}
                  className={`
                     w-full py-4 rounded-xl font-bold text-lg shadow-lg transition-all flex items-center justify-center gap-2
                     ${!image || isGenerating
                       ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                       : 'bg-indigo-600 text-white hover:bg-indigo-700 hover:shadow-indigo-200 hover:-translate-y-0.5'}
                   `}
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5" />
                      Generate Scenes
                    </>
                  )}
                </button>
                
                {error && (
                  <div className="p-4 bg-red-50 text-red-700 rounded-xl text-sm flex items-start gap-2">
                    <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
                    {error}
                  </div>
                )}

              </div>
            </div>
          </div>

          {/* Right Column: Output */}
          <div className="lg:col-span-7 space-y-6">
            {result ? (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold flex items-center gap-2">
                    <Sparkles className="w-6 h-6 text-indigo-600" />
                    Generated Scenes
                  </h2>
                  <button 
                    onClick={() => navigator.clipboard.writeText(result)}
                    className="text-sm text-white font-medium hover:bg-indigo-700 bg-indigo-600 flex items-center gap-1.5 px-4 py-2 rounded-xl transition-colors"
                  >
                    <Copy className="w-4 h-4" />
                    Copy Full Output
                  </button>
                </div>
                
                {parseScenes(result).map((scene, idx) => (
                  <motion.div 
                    key={idx}
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.1 }}
                    className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden flex flex-col"
                  >
                    <div className="p-6 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
                      <h3 className="text-lg font-bold text-slate-800">
                        Scene {scene.num}
                      </h3>
                    </div>
                    
                    <div className="p-6 space-y-6">
                      {/* Voiceover Script */}
                      {scene.voiceover && (
                        <div>
                          <h4 className="font-semibold text-slate-800 mb-2 flex items-center gap-2">
                            <FileText className="w-4 h-4 text-indigo-500" /> Voiceover Script
                          </h4>
                          <div className="bg-slate-100 p-4 rounded-xl text-slate-700 text-sm">
                            <ReactMarkdown components={markdownComponents}>{scene.voiceover}</ReactMarkdown>
                          </div>
                        </div>
                      )}

                      {/* Text to Image */}
                      {scene.textToImage && (
                        <div>
                          <h4 className="font-semibold text-slate-800 mb-2 flex items-center gap-2">
                            <ImageIcon className="w-4 h-4 text-indigo-500" /> Text to Image Prompt
                          </h4>
                          <div className="bg-slate-100 p-4 rounded-xl text-slate-700 text-sm font-mono whitespace-pre-wrap">
                            {scene.textToImage}
                          </div>
                        </div>
                      )}

                      {/* Image to Video */}
                      {scene.imageToVideo && (
                        <div>
                          <h4 className="font-semibold text-slate-800 mb-2 flex items-center gap-2">
                            <Video className="w-4 h-4 text-indigo-500" /> Image to Video Prompt
                          </h4>
                          <div className="bg-slate-100 p-4 rounded-xl text-slate-700 text-sm font-mono whitespace-pre-wrap">
                            {scene.imageToVideo}
                          </div>
                        </div>
                      )}
                      
                      {/* Generative Visuals for Scene */}
                      <div className="pt-6 border-t border-slate-100">
                        {!generatedImages[scene.num] ? (
                          <button
                            onClick={() => generateImageForScene(scene.num, scene.textToImage)}
                            disabled={isGeneratingImageForScene[scene.num]}
                            className={`
                              w-full py-3 rounded-xl font-bold shadow-md transition-all flex items-center justify-center gap-2 text-sm
                              ${isGeneratingImageForScene[scene.num]
                                ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                                : 'bg-indigo-600 text-white hover:bg-indigo-700 hover:shadow-indigo-200'}
                            `}
                          >
                            {isGeneratingImageForScene[scene.num] ? (
                              <>
                                <Loader2 className="w-4 h-4 animate-spin" />
                                Generating Image...
                              </>
                            ) : (
                              <>
                                <Sparkles className="w-4 h-4" />
                                Generate Image for Scene {scene.num}
                              </>
                            )}
                          </button>
                        ) : (
                          <div className="flex flex-col items-center space-y-4">
                            <div className="relative aspect-[9/16] w-full max-w-[240px] rounded-xl overflow-hidden shadow-sm border border-slate-200">
                              <img src={generatedImages[scene.num]} alt={`Scene ${scene.num}`} className="w-full h-full object-cover" />
                            </div>
                            <div className="flex w-full max-w-[240px] gap-2">
                              <a
                                href={generatedImages[scene.num]}
                                download={`scene-${scene.num}.png`}
                                className="flex-1 py-2 text-sm rounded-xl font-medium bg-indigo-600 text-white hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2"
                              >
                                <Download className="w-4 h-4" /> Save
                              </a>
                              <button
                                onClick={() => generateImageForScene(scene.num, scene.textToImage)}
                                disabled={isGeneratingImageForScene[scene.num]}
                                className="flex-1 py-2 text-sm rounded-xl font-medium border border-slate-300 text-slate-700 hover:bg-slate-50 transition-colors flex items-center justify-center gap-2"
                              >
                                {isGeneratingImageForScene[scene.num] ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Retries'}
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            ) : (
               <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden h-full flex flex-col items-center justify-center text-slate-400 p-8 text-center min-h-[500px]">
                  <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mb-4">
                    <Sparkles className="w-8 h-8 text-slate-300" />
                  </div>
                  <p className="text-lg font-medium text-slate-500">No scenes generated yet</p>
                  <p className="max-w-sm mt-2 text-sm text-slate-400">Upload an image and choose an environment to create your scenes.</p>
               </div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
}
